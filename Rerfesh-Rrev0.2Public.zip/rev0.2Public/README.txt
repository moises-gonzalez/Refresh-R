Refresh-R

Refresh-R it is a simple desktop application created to simplify the following:
IE, Chrome, Firefox Browsers cookies and temporary files deletion. Windows clean up function.


How does it work? 
Refersh-R will delete the temporary files located on each browser folders safely and with no mess with your saved passwords or favorites. Refersh-R will delete your windows unnecessary files located on Windows temps and prefetch, user temps, recycle bin.

How start 
Just download, unzip and install. After the installation is completed, you can safely delete the downloaded files. It can be unistalled from Control Panel with no mess left.

Known Glitches 
It can be installed twice or even three times!! If for some reason, it happens to get Refresh-R installed twice or more, no problem! Just go to your Control Panel and uninstall the duplicated installations. (Shortcut by pressing Windos key + R and type appwiz.cpl )

All processes are safe and quick 

Credits 
Moises Gonzalez 
Contact: gonzalez.moises@gmail.com 
Web (under construction by OCT/02/2017): moisesgonzalez.me 
github: https://github.com/moises-gonzalez/Refresh-R

THANK YOU FOR USING Refresh-R public version 